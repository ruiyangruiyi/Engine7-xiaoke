# Session Analysis Techniques for Memory Write-Leg

## Reading Sessions Directly from Disk

The cron write-leg (`memory_extract.py`) uses `session_search` as its primary data source. But for deep historical analysis or when `session_search` returns incomplete results, sessions can be read directly from `~/.hermes/sessions/`.

### File Layout

```
~/.hermes/sessions/
├── sessions.json              # Index of all sessions (JSON)
├── session_<id>.json         # Session metadata + messages (JSON)
├── <date>_<time>_<hash>.jsonl  # Raw message log (JSONL, append-only)
└── session_cron_<jobid>_<timestamp>.json  # Cron session logs
```

### Quick Session Inspection (execute_code)

```python
import json, os, sqlite3
from datetime import datetime

# --- Option 1: state.db (fastest for recent sessions) ---
db_path = '/home/chong/.hermes/state.db'
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Get recent sessions (last 4 hours)
cursor.execute("""
    SELECT id, source, model, started_at, message_count, ended_at, end_reason, title
    FROM sessions
    ORDER BY started_at DESC
    LIMIT 10
""")
for row in cursor.fetchall():
    ts = datetime.fromtimestamp(row[3]).strftime('%Y-%m-%d %H:%M:%S') if row[3] else 'N/A'
    print(f"[{ts}] {row[0][:25]} | {row[1]} | msgs:{row[4]}")

conn.close()

# --- Option 2: sessions.json index ---
import json
with open('/home/chong/.hermes/sessions/sessions.json', 'r') as f:
    index = json.load(f)
for s in index['sessions'][-5:]:
    print(s['session_id'], s.get('source'), s.get('created_at'))
```

### Getting Messages from a Session

```python
import sqlite3
db_path = '/home/chong/.hermes/state.db'
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Get messages — use column name 'timestamp' NOT 'created_at'
cursor.execute("""
    SELECT role, substr(content, 1, 400)
    FROM messages
    WHERE session_id = ? AND role != 'system'
    ORDER BY timestamp ASC
""", (session_id,))

for role, content in cursor.fetchall():
    label = "👤" if role == "user" else "🤖"
    print(f"{label} [{role}]: {content}")

conn.close()
```

### Reading a Session JSON File

```python
import json

# Read session metadata + messages
with open(f'/home/chong/.hermes/sessions/session_{session_id}.json', 'r') as f:
    session = json.load(f)

messages = session.get('messages', [])
print(f"Total messages: {len(messages)}")

for msg in messages:
    role = msg.get('role', '')
    content = msg.get('content', '')
    if isinstance(content, list):
        content = ' | '.join(str(c) for c in content)
    label = "👤" if role == "user" else "🤖"
    preview = str(content)[:200].replace('\n', ' ')
    print(f"{label} {role}: {preview}")
```

### Filtering Cron vs Interactive Sessions

- Cron sessions: `source='cron'` in state.db, filename starts with `session_cron_`
- Interactive sessions: `source='feishu'`/`'web'`/`'terminal'`
- Feishu sessions: `source='feishu'` in state.db
- Cron sessions have `source='cron'`

### When session_search Falls Short (2026-05-10 confirmed)

**Case 1 — Wrong column name crashes query:**
`session_search` uses `created_at` but `messages` table has `timestamp`. Using wrong column name causes `sqlite3.OperationalError: no such column`. Always use `timestamp` for messages, `started_at` for sessions.

**Case 2 — Session too recent to be indexed:**
A session from 5:07 AM was not returned by keyword search for hours. Use `session_search(limit=3)` (recent mode) to get session IDs, then read the state.db directly.

**Case 3 — Partial session already processed by prior cron:**
When a prior cron (e.g., 12pm) read only the first N messages, a later cron needs to read messages N+1 onward from the same `.jsonl` file.

```python
# Incremental reading: skip already-processed messages
with open(f"/home/chong/.hermes/sessions/{session_id}.jsonl", "r") as f:
    lines = f.readlines()

# Prior cron processed lines 0-46 (47 messages)
# This cron processes lines 47 onward
for line in lines[47:]:
    msg = json.loads(line)
    # process new messages...
```

**Fallback hierarchy for write-leg:**
1. `session_search(limit=3)` (recent mode) — get session IDs first
2. state.db — fast SQL for targeted session content
3. `.jsonl` file — incremental reading, survives state.db deletion
4. Keyword search — unreliable for Chinese; prefer recent-mode ID then file read

**state.db confirmed schema (2026-05-10):**

```python
import sqlite3
conn = sqlite3.connect("/home/chong/.hermes/state.db")
cursor = conn.cursor()

# Sessions table columns:
#   id, source, user_id, model, model_config, system_prompt, parent_session_id,
#   started_at (unix float!), message_count, ended_at, end_reason, ...
cursor.execute("SELECT id, source, started_at FROM sessions ORDER BY started_at DESC LIMIT 5")

# Messages table columns:
#   id, session_id, role, content, tool_call_id, tool_calls, tool_name,
#   timestamp (unix float!), token_count, finish_reason, ...
#   ⚠️ NOT 'created_at' — using wrong column name causes OperationalError
cursor.execute("SELECT role, content, timestamp FROM messages WHERE session_id = ? ORDER BY id", [sid])
```

**⚠️ `sessions.message_count` is NOT message count — it's JSON config! (2026-05-13 confirmed)**
```python
# WRONG: thinking message_count is a number of messages
cursor.execute("SELECT * FROM sessions WHERE message_count > 0")  # Always matches JSON string!

# The column stores session creation config like:
#   {"max_iterations": 90, "reasoning_config": null, "max_tokens": null}
# It's max_iterations from when the session was created, NOT how many messages were exchanged.

# Correct way to count actual messages in a session:
cursor.execute("SELECT COUNT(*) FROM messages WHERE session_id = ?", (session_id,))
```
- All Hermes sessions (cron and interactive alike) set `message_count` to this JSON config at creation
- It has nothing to do with actual message volume — don't filter by it
- If you need to know if a session has messages, count from `messages` table or check `source='cron'` (cron sessions) vs `source='feishu'`/`'discord'` (interactive)

**Beijing ↔ UNIX timestamp conversion (2026-05-13 confirmed):**
```python
from datetime import datetime, timezone, timedelta

BJ = timezone(timedelta(hours=8))  # Asia/Shanghai

# Unix timestamp (float) → Beijing time string
ts = 1778659930.1414063
utc_dt = datetime.utcfromtimestamp(ts)
bj_dt = utc_dt.replace(tzinfo=timezone.utc).astimezone(BJ)
print(bj_dt.strftime('%Y-%m-%d %H:%M:%S'))  # 2026-05-13 16:12:10

# Beijing time → Unix timestamp (for state.db queries)
bj_dt = datetime(2026, 5, 13, 16, 12, 10, tzinfo=BJ)
unix_ts = bj_dt.timestamp()
# May 13 2026 00:00 Beijing = May 12 2026 16:00 UTC = 1747132800
# May 13 2026 16:00 Beijing = May 13 2026 08:00 UTC = 1778659200
```

**Key schema facts (2026-05-10 confirmed):**
- `sessions.id` = session ID string (NOT `session_id`)
- `sessions.started_at` = unix timestamp (float), not ISO string
- `messages.session_id` = foreign key to sessions.id
- `messages.timestamp` = unix timestamp, **NOT `created_at`** ( OperationalError if wrong name used)
- `state.db` and JSONL files contain the same messages; JSONL survives state.db deletion/rebuild

**When to use state.db vs JSONL:**
- state.db: faster for targeted queries by session_id, supports SQL aggregation
- JSONL: survives state.db deletion/rebuild, good for incremental reading (line slicing)

### session_search搜不到活跃session（5/14确认，待修memory_extract.py）

**症状**：记忆提取cron每2小时跑一次，一直正常，但几乎每次都判断"零用户交互"→[SILENT]。topic几周停在11个不增长。

**根因**：`session_search` 在多数情况下只返回已完成的session，搜不到当前正在进行的活跃session。翀哥跟小柯聊了一整晚（9点→凌晨3点），期间cron跑了3次（22:06, 00:07, 02:03），每次都搜不到这个对话，全部报告"零用户交互"。

**⚠️ nuance（5/14 04:00 cron实测）**：`session_search(limit=2)` 在 recent模式下**偶尔能找到活跃session**——4AM cron成功拿到了281条消息的活跃Discord会话`20260514_034942_ab177a`。但同夜22:06/00:07/02:03的cron都找不到。可能跟session是否已写入state.db的时机有关，或跟WSL gateway连接状态有关。结论：**session_search对活跃session不可靠，有时能找到有时不能**，不能依赖它作为写入腿的唯一数据源。

**姐姐为什么不受影响**：姐姐的cron用`jsonl_summarizer.py`直接读session JSONL文件增量摘要，不依赖session_search。无论session是否完成，JSONL文件都在磁盘上可以读。

**修复方向**：小柯的`memory_extract.py`改成跟姐姐一样——直接读`~/.hermes/sessions/`下的JSONL文件（或state.db的messages表），按时间增量读取最近2-4小时的消息，不依赖session_search。

**注意**：姐姐的jsonl_summarizer脚本在`/mnt/d/openclaw-new/scripts/jsonl_summarizer.py`，可以直接参考其增量读取逻辑。

### execute_code限制与绕过方案（5/14 cron实战）

**问题**：`execute_code` sandbox对嵌套引号（特别是SQL字符串里嵌套三引号）解析困难。
- `python3 -c "..."` 里包含SQL语句+三引号 → bash eval语法错误（`unexpected EOF`）
- 字符串拼接方式（`code = "..." + code2 = "..."`）也会出问题
- `sqlite3` CLI在WSL里**没装**，不能直接`sqlite3 state.db "..."`

**可靠方案：write_file + terminal**
```python
# Step 1: write Python script to /tmp
from hermes_tools import write_file, terminal

script = '''import sqlite3, datetime
conn = sqlite3.connect('/home/chong/.hermes/state.db')
c = conn.cursor()
c.execute("SELECT role, substr(content, 1, 400), timestamp FROM messages WHERE session_id = 'TARGET_SESSION' ORDER BY timestamp ASC")
rows = c.fetchall()
for r in rows:
    ts = datetime.datetime.fromtimestamp(r[2]).strftime('%H:%M:%S')  # seconds, NOT milliseconds
    role = r[0]
    content = (r[1] or '').replace(chr(10), ' ')[:300]  # ⚠️ r[1] can be None!
    print(f'[{ts}] {role}: {content}')
conn.close()
'''

write_file(path='/tmp/check_session.py', content=script)
result = terminal(command='python3 /tmp/check_session.py')
print(result["output"][:10000])
```

**关键注意事项**：
- **`messages.content`可以是None** — session_meta、部分tool消息的content为NULL，`.replace()`会crash。必须用 `(r[1] or '').replace(...)` 防御
- **timestamp可能看起来像1970年** — 如果用`fromtimestamp(r[2]/1000)`但timestamp实际是秒级（不是毫秒），结果就是1970-01-21这种。Hermes state.db的`messages.timestamp`是秒级浮点（如`1778709608.197`），直接`fromtimestamp(r[2])`不用除1000
- **execute_code sandbox运行在临时目录** — 用`write_file`写脚本到`/tmp/`，然后`terminal`执行，比在sandbox里写复杂Python更可靠
- **terminal输出有长度限制** — 长session的完整消息可能超过`result["output"]`长度，需要分批读取（`OFFSET`+`LIMIT`）或只取关键role

### Large Session Sampling (280+ messages)

When a session is very large (100+ messages), reading every message wastes turns and output budget. Use a sampling strategy:

```python
# Get all messages, sample at intervals + all user messages
c.execute('SELECT role, content FROM messages WHERE session_id = ? ORDER BY rowid', (session_id,))
rows = c.fetchall()
print(f'Total messages: {len(rows)}')

# Show: every 20th message + ALL user messages (user messages are the signal)
for i, r in enumerate(rows):
    if r[0] == 'user' or i % 20 == 0:
        content = r[1][:400] if r[1] else '(empty)'
        print(f'[{i}][{r[0]}] {content}')
```

**Why this works**: User messages contain the intent and new information. Assistant/tool messages in between are usually elaborations. Sampling at 20-message intervals catches the arc of conversation while `r[0] == 'user'` ensures no user intent is missed.

**Then drill into interesting ranges**: If sampled output shows important content at messages 100-130, query that range specifically:
```python
c.execute('SELECT role, content FROM messages WHERE session_id = ? AND rowid BETWEEN 100 AND 130 ORDER BY rowid', (session_id,))
```

### session_search Keyword Mode vs Recent Mode (5/14 confirmed pattern)

**Keyword mode is unreliable for session ID lookups**:
- `session_search(query="session 20260514_040100 discord 280 messages")` → 0 results
- `session_search(query="discord 040100 OR 04:01 OR 凌晨 OR compaction")` → 0 results
- These are valid, specific queries but FTS returns nothing

**Reliable pattern**: Always start with `session_search(limit=2)` in recent mode to get session IDs. Then use `execute_code` + state.db to get message content directly.

**Keyword mode works for**: Broad topic searches across historical sessions (e.g., "迁移 recall hook 姐姐 Hermes"). It fails for: session IDs, exact timestamps, short Chinese phrases.

### Post-Reset Context Recovery（session被reset后恢复上下文）

**场景**：每日schedule reset后（如4am），新session启动但之前对话上下文丢失。用户说"读下之前的session文件"。

**技术**：直接读最近JSONL文件，提取user/assistant消息摘要。

```python
import json

# 1. 找最近的session JSONL（按mtime排序）
# ls -lt ~/.hermes/sessions/ | head -20

# 2. 读JSONL提取对话
with open("~/.hermes/sessions/20260514_034942_ab177a.jsonl") as f:
    for line in f:
        msg = json.loads(line)
        role = msg.get('role','?')
        content = msg.get('content','')
        if isinstance(content, list):
            content = ' '.join([c.get('text','')[:300] for c in content if c.get('type')=='text'])
        elif isinstance(content, str):
            content = content[:300]
        if role in ('user','assistant'):
            print(f'[{role}] {content}')
```

**注意**：
- reset刚发生时，最新JSONL是reset前的session（还没被compaction）
- JSONL是append-only，即使session被标记为ended，文件内容仍在
- `tail -N` 看最后N条消息可以快速了解聊到哪了
- 这是"短期记忆（热记忆）就在session里"的实际体现——不需要存topic就能读
